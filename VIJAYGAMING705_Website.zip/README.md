
# VIJAY GAMING 705 — GitHub Pages website (mobile, bilingual) ✨

This repo is ready to upload to GitHub Pages. It includes a Decap (Netlify) CMS-compatible admin, a simple YouTube video listing system, and a placeholder Tawk.to chat widget.

## Files included
- `index.html` — Main website (Tamil + English toggle)
- `styles.css` — Styling (Red–Purple Gradient)
- `admin/index.html` — Simple admin landing page and instructions
- `admin/config.yml` — Decap CMS configuration (update repo details)
- `/content` — Where CMS-managed content will live (news, videos)
- `/assets` — images and uploads

## Quick deploy (mobile-friendly)
1. Create a GitHub repo named `YOUR_REPO_NAME` (e.g. `vijaygaming705.github.io`).
2. Upload all files and folders to the repo root (preserve the `admin` folder).
3. In `admin/config.yml` replace `YOUR_GITHUB_USERNAME/YOUR_REPO_NAME` with your GitHub username and repo name.
4. In GitHub repo **Settings → Pages**, set source to **main** branch -> `/ (root)` and save.
5. Visit `https://YOUR_GITHUB_USERNAME.github.io` to see the site.
6. Visit `https://YOUR_GITHUB_USERNAME.github.io/admin` to access admin. Use Decap CMS / Netlify CMS setup with GitHub OAuth (see Decap docs).

## Videos & Auto-feed
This site uses a simple content-driven videos JSON in `content/videos.json`. Example format:
```
{
  "videos": [
    {"id":"VIDEO_ID","title":"Title here","thumbnail":"assets/placeholder.jpg"}
  ]
}
```
- You can add video entries manually via the admin (Decap CMS) — creating markdown/json files in `content/videos` folder.
- **To enable automatic YouTube feed** (automatically populate videos):
  1. Get a YouTube Data API key: https://console.developers.google.com/ (enable YouTube Data API v3).
  2. Add a small script in `index.html` or a separate file to fetch `https://www.googleapis.com/youtube/v3/search?key=YOUR_API_KEY&channelId=YOUR_CHANNEL_ID&part=snippet&order=date&maxResults=12` and then write `content/videos.json` (or render on the client).
  3. NOTE: GitHub Pages cannot securely store API keys — recommended approach: create a small serverless function (Netlify Functions / Vercel serverless) or run a local script to update `content/videos.json` in the repo.
  4. The README includes a sample script template (you can run locally or on a small server).

## Live Chat (Tawk.to)
- The index file includes a placeholder Tawk.to script.
- To get your personal Tawk.to ID and messages delivered to your email/console:
  1. Sign up at https://tawk.to (free).
  2. Create a property for your site and copy the embed script's property id (it looks like `5f.../default` or similar).
  3. Replace the `PASTE_TAWK_PROPERTY_ID` string inside `index.html` with your property id (search in file for that string).
- If you prefer, you can keep the placeholder and use a demo account — but to receive messages, you must use your Tawk.to account ID.

## Admin / Decap (Netlify CMS)
- Decap CMS needs additional setup for GitHub OAuth and CORS; follow Decap docs: https://decapcms.org/docs/intro/
- If you prefer a simpler route: edit the JSON files in `content` directly in GitHub (via the web editor). That gives full edit control without external auth.

## How to update videos quickly (recommended)
1. In GitHub, create new files under `content/videos/` (e.g. `my-first-video.json`) using the structure shown above.
2. The site will automatically read `content/videos.json` (create a top-level summary file manually or via script) or render individual files if you modify the fetch logic.

## Replace placeholders
- Replace `PASTE_TAWK_PROPERTY_ID` in `index.html` with your Tawk.to property id.
- Replace `YOUR_GITHUB_USERNAME/YOUR_REPO_NAME` in `admin/config.yml`.
- Add thumbnails to `/assets` or provide external URLs.

## Support
If you want, I can:
- Help set up Decap CMS OAuth with GitHub (step-by-step).
- Provide a small script to auto-fetch YouTube videos using an API key and commit to your repo (requires you to run it once or host on a serverless function).

Enjoy — upload the ZIP to GitHub and your site will be live on GitHub Pages!
